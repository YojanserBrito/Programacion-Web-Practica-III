﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.


var klk = (function () {
    Swal.mixin({
        input: 'text',
        confirmButtonText: 'Next &rarr;',
        showCancelButton: true,
        progressSteps: ['1', '2', '3']
    }).queue([
        {
            title: 'Your Name',
            
        },
        'Your Email Address',
        'Your Question'
    ]).then((result) => {
        if (result.value) {
            Swal.fire({
                title: 'All done!',
                html:
                    'This was the information provided, we will get in contact with you as soon as posibble: <pre><code>' +
                    JSON.stringify(result.value) +
                    '</code></pre>',
                confirmButtonText: 'Accept!'
            })
        }
    })
   });
